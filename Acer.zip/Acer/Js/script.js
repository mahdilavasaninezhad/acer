$(document).ready(function () {
    const nav1 = $(".nav-row1");
    const nav3 = document.querySelector(".nav-row3");
    const forHome = $(".for-home");
    const shop = $(".shop");
    const forWork = $(".for-work");
    const support = $(".support");
    const acerLogo = $(".acer-logo");
    const image1 = $(".image1");
    const image2 = $(".image2");
    const search = $(".search");
    const menuForHome = $(".parent-menu-forhome");
    const menuForWork = $(".parent-menu-forwork");
    const menuSupport = $(".parent-menu-support");
    forHome.mouseenter(function () {
        menuForHome.slideDown(50);
        menuForWork.slideUp(500);
        menuSupport.slideUp(500);
    });
    nav1.mouseenter(function () {
        menuForHome.slideUp();
        menuForWork.slideUp();
        menuSupport.slideUp();
    });
    shop.mouseenter(function () {
        menuForHome.slideUp();
        menuForWork.slideUp();
        menuSupport.slideUp();
    });
    forWork.mouseenter(function () {
        menuForWork.slideDown(50);
        menuForHome.slideUp(500);
        menuSupport.slideUp(500);
    });
    support.mouseenter(function () {
        menuSupport.slideDown(50);
        menuForHome.slideUp(500);
        menuForWork.slideUp(500);
    });
    acerLogo.mouseenter(function () {
        menuForHome.slideUp();
        menuForWork.slideUp();
        menuSupport.slideUp();
    });
    image1.mouseenter(function () {
        menuForHome.slideUp();
        menuForWork.slideUp();
        menuSupport.slideUp();
    });
    image2.mouseenter(function () {
        menuForHome.slideUp();
        menuForWork.slideUp();
        menuSupport.slideUp();
    });
    search.mouseenter(function () {
        menuForHome.slideUp();
        menuForWork.slideUp();
        menuSupport.slideUp();
    });
    const iconSearch = document.querySelector(".icon-search");
    const iconClose = document.querySelector(".icon-close");
    const inputSearch = document.querySelector(".parent-input-search");

    iconSearch.addEventListener("click", function () {
        iconSearch.classList.add("d-none");
        iconClose.classList.add("d-block");
        inputSearch.classList.add("d-flex");
        acerLogo.addClass("d-none");
    });
    iconClose.addEventListener("click", function () {
        iconSearch.classList.remove("d-none");
        iconClose.classList.remove("d-block");
        inputSearch.classList.remove("d-flex");
        acerLogo.removeClass("d-none");
    });

    const goTop = document.querySelector(".go-top-parent");

    document.addEventListener("scroll", function () {
        let threshold = document.documentElement.scrollTop;
        console.log(threshold);
        if (threshold >= 2754 - window.innerHeight) {
            goTop.classList.add("opacity1");
            goTop.classList.add("z-index2");
        }
        else {
            goTop.classList.remove("opacity1");
            goTop.classList.remove("z-index2");
        }
    });
    // lg MENU //

    // for home
    const toggleForHomeLg = $(".for-home-in-menu");
    const iconForHomeLg = document.querySelector(".icon-for-home-lg");
    const MenuForHomeLg = $(".parent-for-home-in-menu");
    // for work
    const toggleForWorkLg = $(".for-work-in-menu");
    const iconForWorkLg = document.querySelector(".icon-for-work-lg");
    const MenuForWorkLg = $(".parent-for-work-in-menu");
    // support
    const toggleSupportLg = $(".support-in-menu");
    const iconSupportLg = document.querySelector(".icon-support-lg");
    const MenuSupportLg = $(".parent-support-in-menu");

    toggleForHomeLg.click(function () {
        MenuForHomeLg.slideToggle();
        iconForHomeLg.classList.toggle("rotate-icon");
        MenuForWorkLg.slideUp();
        iconForWorkLg.classList.remove("rotate-icon");
        MenuSupportLg.slideUp();
        iconSupportLg.classList.remove("rotate-icon");
    });
    toggleForWorkLg.click(function () {
        MenuForWorkLg.slideToggle();
        iconForWorkLg.classList.toggle("rotate-icon");
        MenuForHomeLg.slideUp();
        iconForHomeLg.classList.remove("rotate-icon");
        MenuSupportLg.slideUp();
        iconSupportLg.classList.remove("rotate-icon");
    });
    toggleSupportLg.click(function () {
        MenuSupportLg.slideToggle();
        iconSupportLg.classList.toggle("rotate-icon");
        MenuForHomeLg.slideUp();
        iconForHomeLg.classList.remove("rotate-icon");
        MenuForWorkLg.slideUp();
        iconForWorkLg.classList.remove("rotate-icon");
    });
    // icon toggle menu
    const body = document.querySelector("body");
    const iconOpenMenu = document.querySelector(".icon-open-menu");
    const iconCloseMenu = document.querySelector(".icon-close-menu");
    iconOpenMenu.addEventListener("click", function () {
        nav1.addClass("translateX");
        body.classList.add("over-flow");
        iconCloseMenu.classList.add("d-block");
        iconOpenMenu.classList.add("d-none");
    });
    iconCloseMenu.addEventListener("click", function () {
        nav1.removeClass("translateX");
        body.classList.remove("over-flow");
        iconCloseMenu.classList.remove("d-block");
        iconOpenMenu.classList.remove("d-none");
    });

    // lg fotter //
    
    // about acer
    const listAboutAcerLg = $(".fotter-about-acer-lg");
    const iconAboutAcerLg = document.querySelector(".icon-about-acer-lg");
    const toggleAboutAcerLg = $(".row6-col1");

    toggleAboutAcerLg.click(function () {
        listAboutAcerLg.slideToggle();
        iconAboutAcerLg.classList.toggle("rotate-icon");
        listResourcesLg.slideUp();
        iconResourcesLg.classList.remove("rotate-icon");
        listServiceLg.slideUp();
        iconServiceLg.classList.remove("rotate-icon");
        listLegalLg.slideUp();
        iconLegalLg.classList.remove("rotate-icon");
    });
    // service
    const listServiceLg = $(".fotter-service-lg");
    const iconServiceLg = document.querySelector(".icon-service-lg");
    const toggleServiceLg = $(".row6-col2");

    toggleServiceLg.click(function () {
        listServiceLg.slideToggle();
        iconServiceLg.classList.toggle("rotate-icon");
        listResourcesLg.slideUp();
        iconResourcesLg.classList.remove("rotate-icon");
        listAboutAcerLg.slideUp();
        iconAboutAcerLg.classList.remove("rotate-icon");
        listLegalLg.slideUp();
        iconLegalLg.classList.remove("rotate-icon");
    });
    // resources
    const listResourcesLg = $(".fotter-resources-lg");
    const iconResourcesLg = document.querySelector(".icon-resources-lg");
    const toggleResourcesLg = $(".row6-col3");

    toggleResourcesLg.click(function () {
        listResourcesLg.slideToggle();
        iconResourcesLg.classList.toggle("rotate-icon");
        listServiceLg.slideUp();
        iconServiceLg.classList.remove("rotate-icon");
        listAboutAcerLg.slideUp();
        iconAboutAcerLg.classList.remove("rotate-icon");
        listLegalLg.slideUp();
        iconLegalLg.classList.remove("rotate-icon");
    });
    // legal
    const listLegalLg = $(".fotter-legal-lg");
    const iconLegalLg = document.querySelector(".icon-legal-lg");
    const toggleLegalLg = $(".row6-col4");

    toggleLegalLg.click(function () {
        listLegalLg.slideToggle();
        iconLegalLg.classList.toggle("rotate-icon");
        listServiceLg.slideUp();
        iconServiceLg.classList.remove("rotate-icon");
        listAboutAcerLg.slideUp();
        iconAboutAcerLg.classList.remove("rotate-icon");
        listResourcesLg.slideUp();
        iconResourcesLg.classList.remove("rotate-icon");
    });
});